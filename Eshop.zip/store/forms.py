from django import forms
# from django.forms import ModelForm
# from django import forms

# from store.models import userproducts


# class UserFrom(ModelForm):
#     class Meta:
#         model=userproducts.UserProducts
#         fields=['name','price','category','description','image']



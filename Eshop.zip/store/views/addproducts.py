from email.mime import image
from itertools import product
from django.shortcuts import render , redirect
from django.contrib.auth.hashers import  check_password
from store.models import customer
from store.models.customer import Customer
from store.models.category import Category
# from store.models.userproducts import UserProducts
from django.views import  View
from store.models.product import  Product
from django.core.files.storage import FileSystemStorage
from store.models.orders import Order

 

class Addproducts(View):
    def get(self ,request):
        categories = Category.get_all_categories()
        return render(request , 'addproducts.html'  , {'categories' : categories} )

    def post(self,request):
        name=request.POST.get('name')
        price=request.POST.get('price')
        category_name=request.POST.get('category')
        
        category = Category.get_category_id_by_name(category_name)
        print(category)

        description=request.POST.get('description')

        if request.FILES:
            image=request.FILES['image']
        
        customer = request.session.get('customer')
        
        print(Category(id=category))

        product=Product(name=name,price=price,category=Category(id=category),
                        description=description,image=image,
                        customer=Customer(id=customer))

        product.save()
        return redirect('homepage')
 
